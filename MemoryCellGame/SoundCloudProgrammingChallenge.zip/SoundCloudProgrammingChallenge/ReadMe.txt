ReadMe
=================================================================
This program is written with Xcode 8.1, and the code conforms to Swift3. 

To run the program, open the ‘SoundCloudProgrammingChallenge.xcodeproj’ file and build it to the simulator running on iOS 10.1 or the similar versions.

The project contains both UI Tests and Unit Tests.

=================================================================
Caveat
The UI is optimized to fit iPhone6 or iPhone7 device size. 
